package com.example.progetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class LufaLufa extends AppCompatActivity {
    Button btnVoltar, btnHog;
    private WebView gifL;
    private ListView Lista;
    private String[] person = {"Helga Hufflepuff","Cedrico Diggori","Pomona Sprout","Newton Scamander","Ninfadora Tonks","Ted Lupin","Ernie Macmillan","Ana Abbott"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lufa_lufa);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnVoltar = findViewById(R.id.btnVoltar);
        btnHog = findViewById(R.id.btnHog);
        Lista = findViewById(R.id.Lista);
        gifL = findViewById(R.id.gifL);

        WebSettings gif = gifL.getSettings();
        gif.setJavaScriptEnabled(true);

        String alunos = "file:android_asset/thenum.cedrioc";
        gifL.loadUrl(alunos);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMenu();
            }
        });
        btnHog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirHog();
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_2,android.R.id.text1,person);
        Lista.setAdapter(adapter);
    }
    public void abrirMenu() {
        Intent janelaMenu = new Intent(this, MainActivity.class);
        startActivity(janelaMenu);
    }
    public void abrirHog() {
        Intent janelaHog =new Intent(this, Hogwarts.class);
    }
}