package com.example.progetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.progetofinal.modelo.Pessoa;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private Button btnGrif, btnSons, btnLufa, btnCorv;
    EditText TxtName, TxtEmail;
    ListView listaDados;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnGrif = findViewById(R.id.btnGrif);
        btnSons = findViewById(R.id.btnSons);
        btnLufa = findViewById(R.id.btnLufa);
        btnCorv = findViewById(R.id.btnCorv);
        TxtName = findViewById(R.id.TxtName);
        TxtEmail = findViewById(R.id.TxtEmail);
        listaDados = findViewById(R.id.listaDados);

        inicializarFirebase();

        btnGrif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirGrif();
            }
        });

        btnSons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirSons();
            }
        });

        btnLufa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLufa();
            }
        });

        btnCorv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirCorv();
            }
        });
    }
    public void inicializarFirebase() {
        FirebaseApp.initializeApp (MainActivity.this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }
    public boolean onCreateOptionsMenu(Menu manu){
        getMenuInflater().inflate(R.menu.main_manu, manu);
        return super.onCreateOptionsMenu(manu);
    }
    public boolean onOpcionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.TxtName){
            Pessoa p= new Pessoa ();
            p.setId(UUID.randomUUID().toString());
            p.setNome(TxtName.getText().toString());
            p.setEmail(TxtEmail.getText().toString());

            databaseReference.child("Pessoa").child(p.getId()).setValue(p);
            limparCampos();
        }
        return true;
    }
    public void limparCampos(){
        TxtName.setText("");
        TxtEmail.setText("");
    }

    public void abrirGrif() {
        Intent janelaG = new Intent(this, Grifinoria.class);
        startActivity(janelaG);
    }

    public void abrirSons() {
        Intent janelaS = new Intent(this, Sonserina.class);
        startActivity(janelaS);
    }

    public void abrirLufa() {
        Intent janelaL = new Intent(this, LufaLufa.class);
        startActivity(janelaL);
    }

    public void abrirCorv() {
        Intent janelaC = new Intent(this, Corvinal.class);
        startActivity(janelaC);
    }
}