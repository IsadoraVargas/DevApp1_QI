package com.example.progetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class Corvinal extends AppCompatActivity {
    Button btnVoltar, btnHog;
    private WebView gifC;
    private ListView Lista;
    private String[] person = {"Rowena Ravenclaw","Luna Lovgod","Fílio Flitwick","Gilderoy Lockhart","Cho Chang","Sibila Trelawney","Murta que gema","Padma Patil","Família Olivaras"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_corvinal);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnVoltar = findViewById(R.id.btnVoltar);
        btnHog = findViewById(R.id.btnHog);
        Lista = findViewById(R.id.Lista);
        gifC = findViewById(R.id.gifC);


        WebSettings gif = gifC.getSettings();
        gif.setJavaScriptEnabled(true);

        String alunos = "file:android_asset/thenum.lunapatrono";
        gifC.loadUrl(alunos);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMenu();
            }
        });
        btnHog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirHog();
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_2,android.R.id.text1,person);
        Lista.setAdapter(adapter);
    }
    public void abrirMenu() {
        Intent janelaMenu = new Intent(this, MainActivity.class);
        startActivity(janelaMenu);
    }
    public void abrirHog() {
        Intent janelaHog = new Intent(this, Hogwarts.class);
    }
}