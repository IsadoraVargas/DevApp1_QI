package com.example.progetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.nio.channels.InterruptedByTimeoutException;
import java.util.Vector;

public class Sonserina extends AppCompatActivity {
    private Button btnVoltar, btnHog;
    private WebView gifS;
    private ListView Lista;
    private String[] person = {"Salazar Slytherin","Draco Malfoy","Severus Snape","Bellatrix Lestrange","Tom Riddle","Dolores Umbridge","Lúcio Malfoy","Narcisa Malfoy","Alvo Severo Potter"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sonserina);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnVoltar = findViewById(R.id.btnVoltar);
        btnHog = findViewById(R.id.btnHog);
        Lista = findViewById(R.id.Lista);
        gifS = findViewById(R.id.gifS);

        WebSettings gif = gifS.getSettings();
        gif.setJavaScriptEnabled(true);

        String alunos = "file:android_asset/thenum.dracomalfoy";
        gifS.loadUrl(alunos);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMenu();
            }
        });
        btnHog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirHog();
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_2,android.R.id.text1,person);
        Lista.setAdapter(adapter);
    }
    public void abrirMenu() {
        Intent janelaMenu = new Intent(this, MainActivity.class);
        startActivity(janelaMenu);
    }
    public void abrirHog() {
        Intent janelaHog = new Intent(this, Hogwarts.class);
    }
}