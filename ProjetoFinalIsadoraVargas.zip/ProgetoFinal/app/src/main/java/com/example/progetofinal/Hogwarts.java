package com.example.progetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Hogwarts extends AppCompatActivity {
    private Button btnYoutube, btnJK, btnPottermore, btnLocal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hogwarts);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnJK = findViewById(R.id.btnJK);
        btnPottermore = findViewById(R.id.btnPottermore);
        btnYoutube = findViewById(R.id.btnYoutube);
        btnLocal = findViewById(R.id.btnLocal);


        btnJK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirJKT();
            }
        });
        btnPottermore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPotter();
            }
        });
        btnYoutube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirYoutube();
            }
        });
        btnLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMapa();
            }
        });
    }
    public void abrirJKT(){
        Intent twitter = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/jk_rowling"));
        startActivity(twitter);
    }
    public void abrirPotter(){
        Intent more = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.wizardingworld.com"));
        startActivity(more);
    }
    public void abrirYoutube(){
        Intent Youtube = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/user/MundoDoNada"));
        startActivity(Youtube);
    }
    public  void abrirMapa(){
        Intent Mapa = new Intent(this, Local.class);
    }
}